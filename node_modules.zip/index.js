const express = require('express');
const Blog = require('../models/Blog'); // Убедитесь, что путь к модели верный

const router = express.Router();

// Получение всех блогов
router.get('/blogs', async (req, res) => {
  try {
    const blogs = await Blog.find();
    res.status(200).json(blogs);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Добавление нового блога
router.post('/blogs', async (req, res) => {
  try {
    const { title, body, author } = req.body;
    if (!title || !body) {
      return res.status(400).json({ message: 'Title and Body are required' });
    }
    const blog = new Blog({ title, body, author });
    await blog.save();
    res.status(201).json(blog);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
