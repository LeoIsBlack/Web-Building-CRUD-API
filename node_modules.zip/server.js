const express = require('express');
const mongoose = require('mongoose');
const blogRoutes = require('./blogRoutes');
const dotenv = require('dotenv');

// Initialize environment variables
dotenv.config();

const app = express();
const port = process.env.PORT || 5000;

// Middleware
app.use(express.json());

// MongoDB connection
mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.log('MongoDB connection error:', err));

// API Routes
app.use('/blogs', blogRoutes);

// Start server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
